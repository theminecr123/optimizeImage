Name: libpng
Summary: The PNG reference library
Authors: Cosmin Truta et al.
Version: 1.6.40
License: the libpng license (zlib-like); see LICENSE
URL: http://libpng.org/

Modifications:
 - Added pnglibconf.h.optipng to allow a leaner and meaner libpng build.

Patches:
 - pnglibconf.h.optipng.diff
